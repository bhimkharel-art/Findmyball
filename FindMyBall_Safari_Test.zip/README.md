# FindMyBall Safari Test

This is the fastest way to test the FindMyBall user experience on an iPhone.

## Important

The camera is real.

The GPS permission is real.

The ball detection in this version is still simulated after a few seconds. This lets us test the interface and camera behaviour before putting the real AI model into a web-compatible format.

## How to test

The easiest method is to host `index.html` on HTTPS, because iPhone Safari normally requires a secure context for camera access.

For local testing on a computer, use:

python -m http.server 8000

Then use an HTTPS-capable hosting service for the iPhone.

## Final target

HIT → MARK → WALK → FIND MY BALL → CAMERA SCAN → AI DETECT → CONFIRM

The next version will replace the simulated detector with the actual golf-ball AI.
